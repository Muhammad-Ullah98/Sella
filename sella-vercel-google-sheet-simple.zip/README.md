# Sella — Vercel + Google Sheet lead capture

This version saves signup form submissions to a Google Sheet. It does not open WhatsApp after signup.

## Files
- `public/index.html` — Sella website
- `public/sella-owner-sella-demo-cartoon-owner.mp4` — demo video
- `api/signup.js` — Vercel server-side endpoint

## Setup overview
1. Create a Google Sheet with a tab named `Leads`.
2. Add headers: Timestamp, Name, WhatsApp, Shop, Category, Page, User Agent.
3. In the Sheet, open Extensions → Apps Script.
4. Paste the Apps Script from the setup instructions supplied with this project.
5. Set a private secret in the Apps Script.
6. Deploy the Apps Script as a Web app, executing as you and accessible to anyone with the link.
7. Copy the Web app URL.
8. In Vercel Project Settings → Environment Variables, add:
   - `APPS_SCRIPT_URL` = your Web app URL
   - `APPS_SCRIPT_SECRET` = the same secret used in Apps Script
9. Redeploy. Vercel applies changed environment variables to new deployments.
